public class test {
    public static void main(String[] args) {
        // Create the stock market (subject)
        StockMarket stockMarket = new StockMarket();

        // Create observers
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Change stock price and notify observers
        stockMarket.setStockPrice(162.75);
        stockMarket.setStockPrice(185.30);

        // Deregister an observer and change stock price again
        stockMarket.deregisterObserver(mobileApp);
        stockMarket.setStockPrice(150.00);
    }
}
