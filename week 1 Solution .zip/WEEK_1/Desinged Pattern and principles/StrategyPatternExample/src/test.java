public class test {
    public static void main(String[] args) {
        // Create the context
        PaymentContext paymentContext = new PaymentContext();

        // Set and use Credit Card payment strategy
        PaymentStrategy creditCard = new CreditCardPayment("8797-5674-6234-7890", "Debasis Bhatra");
        paymentContext.setPaymentStrategy(creditCard);
        paymentContext.executePayment(400.0);

        // Set and use PayPal payment strategy
        PaymentStrategy payPal = new PayPalPayment("debasis.bhatra@example.com");
        paymentContext.setPaymentStrategy(payPal);
        paymentContext.executePayment(500.0);
    }
}
